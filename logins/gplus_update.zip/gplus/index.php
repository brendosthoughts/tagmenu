<!doctype html>
<html>
<title>Login with Google Plus</title>
<body>
<div style="margin:0px auto; width:800px;text-align:center;font-family:arial">
<a href='http://9lessons.info'>9lessons.info</a>  
<h1>Login with Google Plus</h1>
<div>
<?php include('gplus_login.php'); ?>
</div>
</div>

</body>
</html>
